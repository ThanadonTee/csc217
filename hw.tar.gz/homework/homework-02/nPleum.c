#include <stdio.h>

int main (void){
	int i;
	int n;
	scanf("%d", &n);
	for (i = 0; i < n; i++){
		printf("Pleum ");
	}
	printf("\n");
return 1;
}
