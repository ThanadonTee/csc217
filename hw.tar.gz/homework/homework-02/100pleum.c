#include <stdio.h>

int main (void){
	int i;
	for (i = 0; i<100; i++){
		printf("Pleum ");
	}
	printf("\n");
return 1;
}
