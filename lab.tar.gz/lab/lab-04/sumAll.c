#include <stdio.h>

int main(){
	printf("Please give me numbers. We will add them up.");
	printf(" You can stop this by typing -1.\n");
	int a;
	int sum = 0;
	scanf("%d", &a);

	while(a != -1){
		sum = sum + a;
		scanf("%d", &a);
	}

	printf("Sum of all your numbers is %d.", sum);
	
	return sum;
}

