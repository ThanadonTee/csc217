#include <stdio.h>

int main(){
	int a,b,c;
	int i;

	for(i = 0; i < 10; i++){
	        
		scanf("%d",&a);
        	scanf("%d",&b);
        	int c = a + b;

        	printf("%d+%d=%d \n",a,b,c);
	}

return 1;
}
